$(document).ready(function () {
    $('#openModalButton').on('click', function (e) {
        e.preventDefault();
        $('#priceModal').fadeIn();
    });

    $('.close').on('click', function () {
        $('#priceModal').fadeOut(); 
    });

    $(window).on('click', function (e) {
        if ($(e.target).is('#priceModal')) {
            $('#priceModal').fadeOut();
        }
    });
});


$(document).ready(function () {
    const rates = {
        USD: 0.00025,
        EUR: 0.00023,
        ARS: 0.09,
        MXN: 0.0044,
        PEN: 0.00095,
    };

    const amountCOP = 1100000; // El valor del peso colombiano, el cual sera multiplicado para la conversion

    const showConversions = () => {
        $('#conversionList').empty();

        $.each(rates, function (currency, rate) {
            const convertedAmount = (amountCOP * rate).toFixed(2);
            $('#conversionList').append(
                `<li>${amountCOP.toLocaleString()} COP = ${convertedAmount} ${currency}</li>`
            );
        });

        $('#priceModal').fadeIn();
    };

    $('#openModalButton').on('click', function (e) {
        e.preventDefault();
        showConversions();
    });

    $('.close').on('click', function () {
        $('#priceModal').fadeOut();
    });
    $(window).on('click', function (e) {
        if ($(e.target).is('#priceModal')) {
            $('#priceModal').fadeOut();
        }
    });
});
/*  Queria poner, cuando le diera click al corazon o al carro de comprar le mandara un mensaje el cual dijera ":( Aun no tenemos en funcionalidad estas opciones por motivos de implementación de cuentas"

$(document).ready(function() {
    // Event handler for when the heart icon is clicked
    $('#heartIcon').on('click', function(event) {
        event.preventDefault(); // Prevent the default action of the link
        $('#messageModal').fadeIn(); // Show the modal with a fade-in effect
    });

    // Event handler for when the cart icon is clicked
    $('#cartIcon').on('click', function(event) {
        event.preventDefault(); // Prevent the default action of the link
        $('#messageModal').fadeIn(); // Show the modal with a fade-in effect 
    });

    // Event handler for closing the modal when the close button is clicked
    $('.close').on('click', function() {
        $('#messageModal').fadeOut(); // Hide the modal with a fade-out effect
    });

    // Event handler for closing the modal when clicking outside of it
    $(window).on('click', function(event) {
        if ($(event.target).is('#messageModal')) { // Check if the clicked target is the modal itself
            $('#messageModal').fadeOut(); // Hide the modal if it is clicked
        }
    });
});
*/
